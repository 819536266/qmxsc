package me.ilt.Bean;

import java.util.ArrayList;

public class bigTypeBean {
private int id;
private String name; //��������
private String remarks;  //��������
private String imgUrl; //����ͼƬ
private ArrayList<smallTypeBean> smallTypeList; //С�༯��
private ArrayList<goodsBean> goods; //����ǰʮ��Ʒ
public bigTypeBean(String name, String remarks) {
	this.name = name;
	this.remarks = remarks;
}
public bigTypeBean() {
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getRemarks() {
	return remarks;
}
public void setRemarks(String remarks) {
	this.remarks = remarks;
}
public String getImgUrl() {
	return imgUrl;
}
public void setImgUrl(String imgUrl) {
	this.imgUrl = imgUrl;
}
public ArrayList<smallTypeBean> getSmallTypeList() {
	return smallTypeList;
}
public void setSmallTypeList(ArrayList<smallTypeBean> smallTypeList) {
	this.smallTypeList = smallTypeList;
}

public ArrayList<goodsBean> getGoods() {
	return goods;
}
public void setGoods(ArrayList<goodsBean> goods) {
	this.goods = goods;
}

}
